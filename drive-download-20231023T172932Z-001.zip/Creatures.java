package textBasedRPG;

public abstract class Creatures extends GameClasses  {

}

