package textBasedRPG;

public interface Classes {

	double attack();
	double fight();

	
	
}
